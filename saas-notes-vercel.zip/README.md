# SaaS Notes App — Ready-to-deploy

This project is a multi-tenant Notes SaaS application (Next.js API routes + minimal frontend) ready for Vercel deployment.

## Quick start (local)

1. Install dependencies:
   ```bash
   npm install
   ```

2. Generate Prisma client:
   ```bash
   npx prisma generate
   ```

3. Seed the database:
   ```bash
   DATABASE_URL="file:./dev.db" npx ts-node prisma/seed.ts
   ```

4. Run development server:
   ```bash
   npm run dev
   ```

Visit http://localhost:3000.

## Predefined accounts (password = password)
- admin@acme.test (Admin)
- user@acme.test (Member)
- admin@globex.test (Admin)
- user@globex.test (Member)

## Endpoints
- GET /api/health
- POST /api/auth/login
- POST /api/tenants/:slug/upgrade (Admin only)
- Notes CRUD: /api/notes (list/create), /api/notes/:id (get/update/delete)

## Multi-tenancy approach
Shared schema using `tenantId` on models. Tenant isolation enforced in API by checking `tenantId` from the JWT.

## Environment variables
- DATABASE_URL (e.g. file:./dev.db or your Postgres URL)
- JWT_SECRET (default: dev_secret)

