import { NextApiRequest } from 'next'
import { verifyToken } from './auth'

export function getTokenFromHeader(req: NextApiRequest) {
  const auth = req.headers.authorization || ''
  if (!auth.startsWith('Bearer ')) return null
  return auth.slice(7)
}

export function requireAuth(req: NextApiRequest) {
  const token = getTokenFromHeader(req)
  if (!token) throw { status: 401, message: 'Missing token' }
  const payload = verifyToken(token)
  if (!payload) throw { status: 401, message: 'Invalid token' }
  return payload as any
}
