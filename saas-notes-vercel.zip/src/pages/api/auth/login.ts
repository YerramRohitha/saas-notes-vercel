import type { NextApiRequest, NextApiResponse } from 'next'
import { authenticate, signToken } from '../../../lib/auth'

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  res.setHeader('Access-Control-Allow-Origin', '*')
  res.setHeader('Access-Control-Allow-Methods', 'POST,OPTIONS')
  res.setHeader('Access-Control-Allow-Headers', '*')
  if (req.method === 'OPTIONS') return res.status(200).end()

  if (req.method !== 'POST') return res.status(405).end()
  const { email, password } = req.body
  const user = await authenticate(email, password)
  if (!user) return res.status(401).json({ error: 'Invalid credentials' })
  const token = signToken({ userId: user.id, role: user.role, tenantId: user.tenantId, tenantSlug: user.tenantSlug })
  res.json({ token })
}
