import type { NextApiRequest, NextApiResponse } from 'next'
import { prisma } from '../../../lib/prisma'
import { requireAuth } from '../../../lib/middleware'

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  res.setHeader('Access-Control-Allow-Origin', '*')
  res.setHeader('Access-Control-Allow-Methods', 'GET,POST,PUT,DELETE,OPTIONS')
  res.setHeader('Access-Control-Allow-Headers', '*')
  if (req.method === 'OPTIONS') return res.status(200).end()

  try {
    const payload: any = requireAuth(req)
    const tenantId = payload.tenantId as number
    const role = payload.role as string

    const parts = req.query.handlers || []
    if (req.method === 'GET' && parts.length === 0) {
      const notes = await prisma.note.findMany({ where: { tenantId }, orderBy: { createdAt: 'desc' } })
      return res.json(notes)
    }

    if (req.method === 'POST' && parts.length === 0) {
      const tenant = await prisma.tenant.findUnique({ where: { id: tenantId } })
      if (!tenant) return res.status(400).json({ error: 'Tenant not found' })

      if (tenant.plan === 'FREE') {
        const count = await prisma.note.count({ where: { tenantId } })
        if (count >= 3) return res.status(402).json({ error: 'Free plan limit reached' })
      }

      const { title, content } = req.body
      const note = await prisma.note.create({ data: { title, content, tenantId, ownerId: payload.userId } })
      return res.status(201).json(note)
    }

    if (parts.length === 1) {
      const id = Number(parts[0])
      const note = await prisma.note.findUnique({ where: { id } })
      if (!note || note.tenantId !== tenantId) return res.status(404).json({ error: 'Note not found' })

      if (req.method === 'GET') return res.json(note)

      if (req.method === 'PUT') {
        const { title, content } = req.body
        const updated = await prisma.note.update({ where: { id }, data: { title, content } })
        return res.json(updated)
      }

      if (req.method === 'DELETE') {
        await prisma.note.delete({ where: { id } })
        return res.json({ ok: true })
      }
    }

    res.status(405).end()
  } catch (err: any) {
    res.status(err.status || 500).json({ error: err.message || String(err) })
  }
}
