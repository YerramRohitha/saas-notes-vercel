import type { NextApiRequest, NextApiResponse } from 'next'
import { prisma } from '../../../../lib/prisma'
import { requireAuth } from '../../../../lib/middleware'

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  res.setHeader('Access-Control-Allow-Origin', '*')
  res.setHeader('Access-Control-Allow-Methods', 'POST,OPTIONS')
  res.setHeader('Access-Control-Allow-Headers', '*')
  if (req.method === 'OPTIONS') return res.status(200).end()
  if (req.method !== 'POST') return res.status(405).end()

  try {
    const payload = requireAuth(req)
    if (payload.role !== 'ADMIN') return res.status(403).json({ error: 'Admin only' })

    const { slug } = req.query
    const tenant = await prisma.tenant.findUnique({ where: { slug: String(slug) } })
    if (!tenant) return res.status(404).json({ error: 'Tenant not found' })

    if (payload.tenantId !== tenant.id) return res.status(403).json({ error: 'Not authorized for this tenant' })

    await prisma.tenant.update({ where: { id: tenant.id }, data: { plan: 'PRO' } })
    res.json({ ok: true })
  } catch (err: any) {
    res.status(err.status || 500).json({ error: err.message || 'Server error' })
  }
}
