import React, { useState, useEffect } from 'react'

const API_BASE = process.env.NEXT_PUBLIC_API_BASE_URL || '/api'

export default function Home() {
  const [email, setEmail] = useState('admin@acme.test')
  const [password, setPassword] = useState('password')
  const [token, setToken] = useState('')
  const [notes, setNotes] = useState<any[]>([])
  const [title, setTitle] = useState('')
  const [content, setContent] = useState('')
  const [tenantSlug, setTenantSlug] = useState('acme')
  const [plan, setPlan] = useState('FREE')

  useEffect(() => {
    const t = localStorage.getItem('token')
    if (t) setToken(t)
  }, [])

  async function login(e: any) {
    e.preventDefault()
    const res = await fetch(`${API_BASE}/auth/login`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ email, password }) })
    const data = await res.json()
    if (data.token) {
      setToken(data.token)
      localStorage.setItem('token', data.token)
      await loadNotes(data.token)
    } else alert('Login failed')
  }

  async function loadNotes(tkn?: string) {
    const tok = tkn || token
    const res = await fetch(`${API_BASE}/notes`, { headers: { Authorization: `Bearer ${tok}` } })
    if (res.status === 401) { alert('Unauthorized'); return }
    const data = await res.json()
    setNotes(Array.isArray(data) ? data : [])
  }

  async function createNote(e: any) {
    e.preventDefault()
    const res = await fetch(`${API_BASE}/notes`, { method: 'POST', headers: { 'content-type': 'application/json', Authorization: `Bearer ${token}` }, body: JSON.stringify({ title, content }) })
    if (res.status === 402) {
      setPlan('FREE')
      alert('Free plan limit reached — click Upgrade to Pro (Admin only)')
      return
    }
    const data = await res.json()
    setNotes(prev => [data, ...prev])
    setTitle('')
    setContent('')
  }

  async function del(id: number) {
    await fetch(`${API_BASE}/notes/${id}`, { method: 'DELETE', headers: { Authorization: `Bearer ${token}` } })
    setNotes(prev => prev.filter(n => n.id !== id))
  }

  async function upgrade() {
    const res = await fetch(`${API_BASE}/tenants/${tenantSlug}/upgrade`, { method: 'POST', headers: { Authorization: `Bearer ${token}` } })
    if (res.ok) { alert('Upgraded to PRO'); setPlan('PRO') }
    else { const err = await res.json(); alert('Upgrade failed: ' + (err.error||'')) }
  }

  return (
    <div style={{ padding: 20, fontFamily: 'system-ui, sans-serif' }}>
      <h1>SaaS Notes — Minimal Frontend</h1>

      {!token && (
        <form onSubmit={login} style={{ marginBottom: 12 }}>
          <div>
            <label>Email: </label>
            <input value={email} onChange={e => setEmail(e.target.value)} />
          </div>
          <div>
            <label>Password: </label>
            <input type="password" value={password} onChange={e => setPassword(e.target.value)} />
          </div>
          <div>
            <button type="submit">Login</button>
          </div>
        </form>
      )}

      {token && (
        <div>
          <div style={{ marginBottom: 12 }}>
            <button onClick={() => { localStorage.removeItem('token'); setToken(''); setNotes([]) }}>Logout</button>
            <span style={{ marginLeft: 12 }}>Tenant slug (for upgrade button): </span>
            <input value={tenantSlug} onChange={e => setTenantSlug(e.target.value)} style={{ width: 120 }} />
            <button onClick={() => loadNotes()} style={{ marginLeft: 8 }}>Refresh notes</button>
            <button onClick={upgrade} style={{ marginLeft: 8 }}>Upgrade to Pro</button>
          </div>

          <form onSubmit={createNote} style={{ marginBottom: 12 }}>
            <div>
              <input placeholder="Title" value={title} onChange={e => setTitle(e.target.value)} />
            </div>
            <div>
              <textarea placeholder="Content" value={content} onChange={e => setContent(e.target.value)} />
            </div>
            <div>
              <button type="submit">Create Note</button>
            </div>
          </form>

          <h3>Notes</h3>
          <ul>
            {notes.map(n => (
              <li key={n.id} style={{ marginBottom: 8 }}>
                <strong>{n.title}</strong> — <button onClick={() => del(n.id)}>Delete</button>
                <div>{n.content}</div>
              </li>
            ))}
          </ul>
        </div>
      )}

      <hr />
      <div>
        <h4>Predefined test accounts (password = password)</h4>
        <ul>
          <li>admin@acme.test (Admin)</li>
          <li>user@acme.test (Member)</li>
          <li>admin@globex.test (Admin)</li>
          <li>user@globex.test (Member)</li>
        </ul>
      </div>
    </div>
  )
}
